# Joint Project for AC209A and CS1710

## Topic
How do local demographics affect voter turnout in Massachusetts?

## Group Members
- Anitej Thamma (CS1710 only)
- Max Bahar 
- Stefan Chu 
- Ted McCulloch 

## Data
- MA_l2_2022stats_2020block (2022 voter turnout data for MA census blocks)
- ma_pl2020_b (Shapefile for 2020 MA census blocks)