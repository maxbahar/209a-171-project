L2 Voter File 2022 Elections Turnout Statistics for MA, aggregated to the 2020 Census Block level 

## Redistricting Data Hub (RDH) Retrieval Date
6/13/2023

## Sources
The Redistricting Data Hub purchased this Voter File from L2, a national Voter File vendor: https://l2-data.com/

## Fields
The fields below are from the L2 Voter File pulled by the RDH on 6/13/2023. 
L2 retrieved this voter file data from the state between April 3 and June 13 2023.
To see more detailed field descriptions, please view the attached data dictionary provided by L2. 
All fields are for individuals who are registered on the L2 Voter File as of the date of retrieval. The RDH did not have access to legacy or snapshot voter files. 
Field Name                                   		Description
geoid20                                      		15-character GEOID corresponding to 2020 Census Blocks, based on L2 geo-referencing of individual voter addresses
total_reg                                    		Count of total registered voters in the County, as geo-referenced by RDH from L2 voter file dated above
age_18_19                                    		Count of voters between the age of 18 and 19 in the Census Block
age_20_24                                    		Count of voters between the age of 20 and 24 in the Census Block
age_25_29                                    		Count of voters between the age of 25 and 29 in the Census Block
age_30_34                                    		Count of voters between the age of 30 and 34 in the Census Block
age_35_44                                    		Count of voters between the age of 35 and 44 in the Census Block
age_45_54                                    		Count of voters between the age of 45 and 54 in the Census Block
age_55_64                                    		Count of voters between the age of 55 and 64 in the Census Block
age_65_74                                    		Count of voters between the age of 65 and 74 in the Census Block
age_75_84                                    		Count of voters between the age of 75 and 84 in the Census Block
age_85over                                   		Count of voters over the age of 85 in the Census Block
voters_gender_m                              		Count of male voters
voters_gender_f                              		Count of female voters
voters_gender_unknown                        		Count of voters with unknown or other gender
party_npp                                    		Count of voters registered with the following party on the L2 Voter File: Non-Partisan *
party_dem                                    		Count of voters registered with the following party on the L2 Voter File: Democratic *
party_rep                                    		Count of voters registered with the following party on the L2 Voter File: Republican *
party_lib                                    		Count of voters registered with the following party on the L2 Voter File: Libertarian *
party_grn                                    		Count of voters registered with the following party on the L2 Voter File: Green *
party_con                                    		Count of voters registered with the following party on the L2 Voter File: Conservative *
party_ain                                    		Count of voters registered with the following party on the L2 Voter File: American Independent *
party_scl                                    		Count of voters registered with the following party on the L2 Voter File: Socialist *
party_oth                                    		Count of voters registered with another party, not listed above, on the L2 Voter File
party_unk                                    		Count of voters with unknown (null) party affiliation on the L2 Voter File
eth1_eur                                     		Count of voters in the following broad ethnicity category, defined by L2: European
eth1_hisp                                    		Count of voters in the following broad ethnicity category, defined by L2: Hispanic and Portuguese
eth1_aa                                      		Count of voters in the following broad ethnicity category, defined by L2: Likely African-American
eth1_esa                                     		Count of voters in the following broad ethnicity category, defined by L2: East and South Asian
eth1_oth                                     		Count of voters in the following broad ethnicity category, defined by L2: Other
eth1_unk                                     		Count of voters with unknown (null) broad ethnicity category
eth2_euro                                    		Count of voters in the following narrow ethnicity category, defined by L2: Summed European narrow ethnicities (see notes for what is included) **
eth2_64                                      		Count of voters in the following narrow ethnicity category, defined by L2: Hispanic **
eth2_93                                      		Count of voters in the following narrow ethnicity category, defined by L2: Likely Af-Am (Modeled) **
eth2_10                                      		Count of voters in the following narrow ethnicity category, defined by L2: Chinese **
eth2_30                                      		Count of voters in the following narrow ethnicity category, defined by L2: Arab **
eth2_23                                      		Count of voters in the following narrow ethnicity category, defined by L2: Indian/Hindu **
eth2_66                                      		Count of voters in the following narrow ethnicity category, defined by L2: Portuguese **
eth2_34                                      		Count of voters in the following narrow ethnicity category, defined by L2: Russian (omitting former Soviet States) **
eth2_21                                      		Count of voters in the following narrow ethnicity category, defined by L2: Vietnamese **
eth2_35                                      		Count of voters in the following narrow ethnicity category, defined by L2: Armenian **
eth2_14                                      		Count of voters in the following narrow ethnicity category, defined by L2: Korean **
eth2_12                                      		Count of voters in the following narrow ethnicity category, defined by L2: Japanese **
eth2_55                                      		Count of voters in the following narrow ethnicity category, defined by L2: Ukrainian **
eth2_13                                      		Count of voters in the following narrow ethnicity category, defined by L2: Khmer **
eth2_32                                      		Count of voters in the following narrow ethnicity category, defined by L2: Persian **
eth2_61                                      		Count of voters in the following narrow ethnicity category, defined by L2: Serbian **
eth2_85                                      		Count of voters in the following narrow ethnicity category, defined by L2: Filipino **
eth2_29                                      		Count of voters in the following narrow ethnicity category, defined by L2: Pakistani **
eth2_33                                      		Count of voters in the following narrow ethnicity category, defined by L2: Turkish **
eth2_38                                      		Count of voters in the following narrow ethnicity category, defined by L2: Byelorussian **
eth2_15                                      		Count of voters in the following narrow ethnicity category, defined by L2: Laotian **
eth2_57                                      		Count of voters in the following narrow ethnicity category, defined by L2: Albanian **
eth2_19                                      		Count of voters in the following narrow ethnicity category, defined by L2: Thai **
eth2_26                                      		Count of voters in the following narrow ethnicity category, defined by L2: Unknown Asian **
eth2_59                                      		Count of voters in the following narrow ethnicity category, defined by L2: Croatian **
eth2_unk                                     		Count of voters with unknown (null) narrow ethnicity category
languages_description_English                		Count of voters on the L2 Voter File known to speak the language: English
languages_description_Spanish                		Count of voters on the L2 Voter File known to speak the language: Spanish
languages_description_Portuguese             		Count of voters on the L2 Voter File known to speak the language: Portuguese
languages_description_Chinese                		Count of voters on the L2 Voter File known to speak the language: Chinese
languages_description_Italian                		Count of voters on the L2 Voter File known to speak the language: Italian
languages_description_Vietnamese             		Count of voters on the L2 Voter File known to speak the language: Vietnamese
commercialdata_estimatedhhincomeamount_avg   		Average of modeled data for estimated household income reported by L2 for individuals in the following ranges:  $1,000-$14,999/$15,000-$24,999/$25,000-$49,999/$50,000-$74,999/$75,000-$99,999/$100,000-$124,999/$125,000-$149,999/$150,000-$174,999/$175,000-$199,999/$200,000-$249,999/$250,000+
g20221108_voted_all                          		Count of voters who voted in the following election: general_2022_11_08
g20221108_reg_all                            		Count of voters registered on or before: 2022-11-08
g20221108_pct_voted_all                      		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08
g20221108_voted_gender_m                     		Count of voters who voted in the following election: general_2022_11_08, L2 Gender: Male
g20221108_reg_gender_m                       		Count of voters registered on or before: 2022-11-08, L2 Gender: Male
g20221108_pct_voted_gender_m                 		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Gender: Male
g20221108_voted_gender_f                     		Count of voters who voted in the following election: general_2022_11_08, L2 Gender: Female
g20221108_reg_gender_f                       		Count of voters registered on or before: 2022-11-08, L2 Gender: Female
g20221108_pct_voted_gender_f                 		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Gender: Female
g20221108_voted_gender_unk                   		Count of voters who voted in the following election: general_2022_11_08, L2 Gender: Unknown
g20221108_reg_gender_unk                     		Count of voters registered on or before: 2022-11-08, L2 Gender: Unknown
g20221108_pct_voted_gender_unk               		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Gender: Unknown
g20221108_voted_eur                          		Count of voters who voted in the following election: general_2022_11_08, L2 Race or Ethnicity: European
g20221108_reg_eur                            		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: European
g20221108_pct_voted_eur                      		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Race or Ethnicity: European
g20221108_voted_hisp                         		Count of voters who voted in the following election: general_2022_11_08, L2 Race or Ethnicity: Hispanic and Portuguese
g20221108_reg_hisp                           		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: Hispanic and Portuguese
g20221108_pct_voted_hisp                     		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Race or Ethnicity: Hispanic and Portuguese
g20221108_voted_aa                           		Count of voters who voted in the following election: general_2022_11_08, L2 Race or Ethnicity: Likely African-American
g20221108_reg_aa                             		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: Likely African-American
g20221108_pct_voted_aa                       		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Race or Ethnicity: Likely African-American
g20221108_voted_esa                          		Count of voters who voted in the following election: general_2022_11_08, L2 Race or Ethnicity: East and South Asian
g20221108_reg_esa                            		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: East and South Asian
g20221108_pct_voted_esa                      		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Race or Ethnicity: East and South Asian
g20221108_voted_oth                          		Count of voters who voted in the following election: general_2022_11_08, L2 Race or Ethnicity: Other
g20221108_reg_oth                            		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: Other
g20221108_pct_voted_oth                      		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Race or Ethnicity: Other
g20221108_voted_unk                          		Count of voters who voted in the following election: general_2022_11_08, L2 Race or Ethnicity: Unknown
g20221108_reg_unk                            		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: Unknown
g20221108_pct_voted_unk                      		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Race or Ethnicity: Unknown
p20220906_voted_all                          		Count of voters who voted in the following election: primary_2022_09_06
p20220906_reg_all                            		Count of voters registered on or before: 2022-09-06
p20220906_pct_voted_all                      		Percent of voters registered on or before 2022-09-06 and who voted in: primary_2022_09_06
p20220906_voted_gender_m                     		Count of voters who voted in the following election: primary_2022_09_06, L2 Gender: Male
p20220906_reg_gender_m                       		Count of voters registered on or before: 2022-09-06, L2 Gender: Male
p20220906_pct_voted_gender_m                 		Percent of voters registered on or before 2022-09-06 and who voted in: primary_2022_09_06, L2 Gender: Male
p20220906_voted_gender_f                     		Count of voters who voted in the following election: primary_2022_09_06, L2 Gender: Female
p20220906_reg_gender_f                       		Count of voters registered on or before: 2022-09-06, L2 Gender: Female
p20220906_pct_voted_gender_f                 		Percent of voters registered on or before 2022-09-06 and who voted in: primary_2022_09_06, L2 Gender: Female
p20220906_voted_gender_unk                   		Count of voters who voted in the following election: primary_2022_09_06, L2 Gender: Unknown
p20220906_reg_gender_unk                     		Count of voters registered on or before: 2022-09-06, L2 Gender: Unknown
p20220906_pct_voted_gender_unk               		Percent of voters registered on or before 2022-09-06 and who voted in: primary_2022_09_06, L2 Gender: Unknown
p20220906_voted_eur                          		Count of voters who voted in the following election: primary_2022_09_06, L2 Race or Ethnicity: European
p20220906_reg_eur                            		Count of voters registered on or before: 2022-09-06, L2 Race or Ethnicity: European
p20220906_pct_voted_eur                      		Percent of voters registered on or before 2022-09-06 and who voted in: primary_2022_09_06, L2 Race or Ethnicity: European
p20220906_voted_hisp                         		Count of voters who voted in the following election: primary_2022_09_06, L2 Race or Ethnicity: Hispanic and Portuguese
p20220906_reg_hisp                           		Count of voters registered on or before: 2022-09-06, L2 Race or Ethnicity: Hispanic and Portuguese
p20220906_pct_voted_hisp                     		Percent of voters registered on or before 2022-09-06 and who voted in: primary_2022_09_06, L2 Race or Ethnicity: Hispanic and Portuguese
p20220906_voted_aa                           		Count of voters who voted in the following election: primary_2022_09_06, L2 Race or Ethnicity: Likely African-American
p20220906_reg_aa                             		Count of voters registered on or before: 2022-09-06, L2 Race or Ethnicity: Likely African-American
p20220906_pct_voted_aa                       		Percent of voters registered on or before 2022-09-06 and who voted in: primary_2022_09_06, L2 Race or Ethnicity: Likely African-American
p20220906_voted_esa                          		Count of voters who voted in the following election: primary_2022_09_06, L2 Race or Ethnicity: East and South Asian
p20220906_reg_esa                            		Count of voters registered on or before: 2022-09-06, L2 Race or Ethnicity: East and South Asian
p20220906_pct_voted_esa                      		Percent of voters registered on or before 2022-09-06 and who voted in: primary_2022_09_06, L2 Race or Ethnicity: East and South Asian
p20220906_voted_oth                          		Count of voters who voted in the following election: primary_2022_09_06, L2 Race or Ethnicity: Other
p20220906_reg_oth                            		Count of voters registered on or before: 2022-09-06, L2 Race or Ethnicity: Other
p20220906_pct_voted_oth                      		Percent of voters registered on or before 2022-09-06 and who voted in: primary_2022_09_06, L2 Race or Ethnicity: Other
p20220906_voted_unk                          		Count of voters who voted in the following election: primary_2022_09_06, L2 Race or Ethnicity: Unknown
p20220906_reg_unk                            		Count of voters registered on or before: 2022-09-06, L2 Race or Ethnicity: Unknown
p20220906_pct_voted_unk                      		Percent of voters registered on or before 2022-09-06 and who voted in: primary_2022_09_06, L2 Race or Ethnicity: Unknown
s20211214_voted_all                          		Count of voters who voted in the following election: special_2021_12_14
s20211214_reg_all                            		Count of voters registered on or before: 2021-12-14
s20211214_pct_voted_all                      		Percent of voters registered on or before 2021-12-14 and who voted in: special_2021_12_14
s20211214_voted_gender_m                     		Count of voters who voted in the following election: special_2021_12_14, L2 Gender: Male
s20211214_reg_gender_m                       		Count of voters registered on or before: 2021-12-14, L2 Gender: Male
s20211214_pct_voted_gender_m                 		Percent of voters registered on or before 2021-12-14 and who voted in: special_2021_12_14, L2 Gender: Male
s20211214_voted_gender_f                     		Count of voters who voted in the following election: special_2021_12_14, L2 Gender: Female
s20211214_reg_gender_f                       		Count of voters registered on or before: 2021-12-14, L2 Gender: Female
s20211214_pct_voted_gender_f                 		Percent of voters registered on or before 2021-12-14 and who voted in: special_2021_12_14, L2 Gender: Female
s20211214_voted_gender_unk                   		Count of voters who voted in the following election: special_2021_12_14, L2 Gender: Unknown
s20211214_reg_gender_unk                     		Count of voters registered on or before: 2021-12-14, L2 Gender: Unknown
s20211214_pct_voted_gender_unk               		Percent of voters registered on or before 2021-12-14 and who voted in: special_2021_12_14, L2 Gender: Unknown
s20211214_voted_eur                          		Count of voters who voted in the following election: special_2021_12_14, L2 Race or Ethnicity: European
s20211214_reg_eur                            		Count of voters registered on or before: 2021-12-14, L2 Race or Ethnicity: European
s20211214_pct_voted_eur                      		Percent of voters registered on or before 2021-12-14 and who voted in: special_2021_12_14, L2 Race or Ethnicity: European
s20211214_voted_hisp                         		Count of voters who voted in the following election: special_2021_12_14, L2 Race or Ethnicity: Hispanic and Portuguese
s20211214_reg_hisp                           		Count of voters registered on or before: 2021-12-14, L2 Race or Ethnicity: Hispanic and Portuguese
s20211214_pct_voted_hisp                     		Percent of voters registered on or before 2021-12-14 and who voted in: special_2021_12_14, L2 Race or Ethnicity: Hispanic and Portuguese
s20211214_voted_aa                           		Count of voters who voted in the following election: special_2021_12_14, L2 Race or Ethnicity: Likely African-American
s20211214_reg_aa                             		Count of voters registered on or before: 2021-12-14, L2 Race or Ethnicity: Likely African-American
s20211214_pct_voted_aa                       		Percent of voters registered on or before 2021-12-14 and who voted in: special_2021_12_14, L2 Race or Ethnicity: Likely African-American
s20211214_voted_esa                          		Count of voters who voted in the following election: special_2021_12_14, L2 Race or Ethnicity: East and South Asian
s20211214_reg_esa                            		Count of voters registered on or before: 2021-12-14, L2 Race or Ethnicity: East and South Asian
s20211214_pct_voted_esa                      		Percent of voters registered on or before 2021-12-14 and who voted in: special_2021_12_14, L2 Race or Ethnicity: East and South Asian
s20211214_voted_oth                          		Count of voters who voted in the following election: special_2021_12_14, L2 Race or Ethnicity: Other
s20211214_reg_oth                            		Count of voters registered on or before: 2021-12-14, L2 Race or Ethnicity: Other
s20211214_pct_voted_oth                      		Percent of voters registered on or before 2021-12-14 and who voted in: special_2021_12_14, L2 Race or Ethnicity: Other
s20211214_voted_unk                          		Count of voters who voted in the following election: special_2021_12_14, L2 Race or Ethnicity: Unknown
s20211214_reg_unk                            		Count of voters registered on or before: 2021-12-14, L2 Race or Ethnicity: Unknown
s20211214_pct_voted_unk                      		Percent of voters registered on or before 2021-12-14 and who voted in: special_2021_12_14, L2 Race or Ethnicity: Unknown
s20211130_voted_all                          		Count of voters who voted in the following election: special_2021_11_30
s20211130_reg_all                            		Count of voters registered on or before: 2021-11-30
s20211130_pct_voted_all                      		Percent of voters registered on or before 2021-11-30 and who voted in: special_2021_11_30
s20211130_voted_gender_m                     		Count of voters who voted in the following election: special_2021_11_30, L2 Gender: Male
s20211130_reg_gender_m                       		Count of voters registered on or before: 2021-11-30, L2 Gender: Male
s20211130_pct_voted_gender_m                 		Percent of voters registered on or before 2021-11-30 and who voted in: special_2021_11_30, L2 Gender: Male
s20211130_voted_gender_f                     		Count of voters who voted in the following election: special_2021_11_30, L2 Gender: Female
s20211130_reg_gender_f                       		Count of voters registered on or before: 2021-11-30, L2 Gender: Female
s20211130_pct_voted_gender_f                 		Percent of voters registered on or before 2021-11-30 and who voted in: special_2021_11_30, L2 Gender: Female
s20211130_voted_gender_unk                   		Count of voters who voted in the following election: special_2021_11_30, L2 Gender: Unknown
s20211130_reg_gender_unk                     		Count of voters registered on or before: 2021-11-30, L2 Gender: Unknown
s20211130_pct_voted_gender_unk               		Percent of voters registered on or before 2021-11-30 and who voted in: special_2021_11_30, L2 Gender: Unknown
s20211130_voted_eur                          		Count of voters who voted in the following election: special_2021_11_30, L2 Race or Ethnicity: European
s20211130_reg_eur                            		Count of voters registered on or before: 2021-11-30, L2 Race or Ethnicity: European
s20211130_pct_voted_eur                      		Percent of voters registered on or before 2021-11-30 and who voted in: special_2021_11_30, L2 Race or Ethnicity: European
s20211130_voted_hisp                         		Count of voters who voted in the following election: special_2021_11_30, L2 Race or Ethnicity: Hispanic and Portuguese
s20211130_reg_hisp                           		Count of voters registered on or before: 2021-11-30, L2 Race or Ethnicity: Hispanic and Portuguese
s20211130_pct_voted_hisp                     		Percent of voters registered on or before 2021-11-30 and who voted in: special_2021_11_30, L2 Race or Ethnicity: Hispanic and Portuguese
s20211130_voted_aa                           		Count of voters who voted in the following election: special_2021_11_30, L2 Race or Ethnicity: Likely African-American
s20211130_reg_aa                             		Count of voters registered on or before: 2021-11-30, L2 Race or Ethnicity: Likely African-American
s20211130_pct_voted_aa                       		Percent of voters registered on or before 2021-11-30 and who voted in: special_2021_11_30, L2 Race or Ethnicity: Likely African-American
s20211130_voted_esa                          		Count of voters who voted in the following election: special_2021_11_30, L2 Race or Ethnicity: East and South Asian
s20211130_reg_esa                            		Count of voters registered on or before: 2021-11-30, L2 Race or Ethnicity: East and South Asian
s20211130_pct_voted_esa                      		Percent of voters registered on or before 2021-11-30 and who voted in: special_2021_11_30, L2 Race or Ethnicity: East and South Asian
s20211130_voted_oth                          		Count of voters who voted in the following election: special_2021_11_30, L2 Race or Ethnicity: Other
s20211130_reg_oth                            		Count of voters registered on or before: 2021-11-30, L2 Race or Ethnicity: Other
s20211130_pct_voted_oth                      		Percent of voters registered on or before 2021-11-30 and who voted in: special_2021_11_30, L2 Race or Ethnicity: Other
s20211130_voted_unk                          		Count of voters who voted in the following election: special_2021_11_30, L2 Race or Ethnicity: Unknown
s20211130_reg_unk                            		Count of voters registered on or before: 2021-11-30, L2 Race or Ethnicity: Unknown
s20211130_pct_voted_unk                      		Percent of voters registered on or before 2021-11-30 and who voted in: special_2021_11_30, L2 Race or Ethnicity: Unknown
s20211102_voted_all                          		Count of voters who voted in the following election: special_2021_11_02
s20211102_reg_all                            		Count of voters registered on or before: 2021-11-02
s20211102_pct_voted_all                      		Percent of voters registered on or before 2021-11-02 and who voted in: special_2021_11_02
s20211102_voted_gender_m                     		Count of voters who voted in the following election: special_2021_11_02, L2 Gender: Male
s20211102_reg_gender_m                       		Count of voters registered on or before: 2021-11-02, L2 Gender: Male
s20211102_pct_voted_gender_m                 		Percent of voters registered on or before 2021-11-02 and who voted in: special_2021_11_02, L2 Gender: Male
s20211102_voted_gender_f                     		Count of voters who voted in the following election: special_2021_11_02, L2 Gender: Female
s20211102_reg_gender_f                       		Count of voters registered on or before: 2021-11-02, L2 Gender: Female
s20211102_pct_voted_gender_f                 		Percent of voters registered on or before 2021-11-02 and who voted in: special_2021_11_02, L2 Gender: Female
s20211102_voted_gender_unk                   		Count of voters who voted in the following election: special_2021_11_02, L2 Gender: Unknown
s20211102_reg_gender_unk                     		Count of voters registered on or before: 2021-11-02, L2 Gender: Unknown
s20211102_pct_voted_gender_unk               		Percent of voters registered on or before 2021-11-02 and who voted in: special_2021_11_02, L2 Gender: Unknown
s20211102_voted_eur                          		Count of voters who voted in the following election: special_2021_11_02, L2 Race or Ethnicity: European
s20211102_reg_eur                            		Count of voters registered on or before: 2021-11-02, L2 Race or Ethnicity: European
s20211102_pct_voted_eur                      		Percent of voters registered on or before 2021-11-02 and who voted in: special_2021_11_02, L2 Race or Ethnicity: European
s20211102_voted_hisp                         		Count of voters who voted in the following election: special_2021_11_02, L2 Race or Ethnicity: Hispanic and Portuguese
s20211102_reg_hisp                           		Count of voters registered on or before: 2021-11-02, L2 Race or Ethnicity: Hispanic and Portuguese
s20211102_pct_voted_hisp                     		Percent of voters registered on or before 2021-11-02 and who voted in: special_2021_11_02, L2 Race or Ethnicity: Hispanic and Portuguese
s20211102_voted_aa                           		Count of voters who voted in the following election: special_2021_11_02, L2 Race or Ethnicity: Likely African-American
s20211102_reg_aa                             		Count of voters registered on or before: 2021-11-02, L2 Race or Ethnicity: Likely African-American
s20211102_pct_voted_aa                       		Percent of voters registered on or before 2021-11-02 and who voted in: special_2021_11_02, L2 Race or Ethnicity: Likely African-American
s20211102_voted_esa                          		Count of voters who voted in the following election: special_2021_11_02, L2 Race or Ethnicity: East and South Asian
s20211102_reg_esa                            		Count of voters registered on or before: 2021-11-02, L2 Race or Ethnicity: East and South Asian
s20211102_pct_voted_esa                      		Percent of voters registered on or before 2021-11-02 and who voted in: special_2021_11_02, L2 Race or Ethnicity: East and South Asian
s20211102_voted_oth                          		Count of voters who voted in the following election: special_2021_11_02, L2 Race or Ethnicity: Other
s20211102_reg_oth                            		Count of voters registered on or before: 2021-11-02, L2 Race or Ethnicity: Other
s20211102_pct_voted_oth                      		Percent of voters registered on or before 2021-11-02 and who voted in: special_2021_11_02, L2 Race or Ethnicity: Other
s20211102_voted_unk                          		Count of voters who voted in the following election: special_2021_11_02, L2 Race or Ethnicity: Unknown
s20211102_reg_unk                            		Count of voters registered on or before: 2021-11-02, L2 Race or Ethnicity: Unknown
s20211102_pct_voted_unk                      		Percent of voters registered on or before 2021-11-02 and who voted in: special_2021_11_02, L2 Race or Ethnicity: Unknown
s20210330_voted_all                          		Count of voters who voted in the following election: special_2021_03_30
s20210330_reg_all                            		Count of voters registered on or before: 2021-03-30
s20210330_pct_voted_all                      		Percent of voters registered on or before 2021-03-30 and who voted in: special_2021_03_30
s20210330_voted_gender_m                     		Count of voters who voted in the following election: special_2021_03_30, L2 Gender: Male
s20210330_reg_gender_m                       		Count of voters registered on or before: 2021-03-30, L2 Gender: Male
s20210330_pct_voted_gender_m                 		Percent of voters registered on or before 2021-03-30 and who voted in: special_2021_03_30, L2 Gender: Male
s20210330_voted_gender_f                     		Count of voters who voted in the following election: special_2021_03_30, L2 Gender: Female
s20210330_reg_gender_f                       		Count of voters registered on or before: 2021-03-30, L2 Gender: Female
s20210330_pct_voted_gender_f                 		Percent of voters registered on or before 2021-03-30 and who voted in: special_2021_03_30, L2 Gender: Female
s20210330_voted_gender_unk                   		Count of voters who voted in the following election: special_2021_03_30, L2 Gender: Unknown
s20210330_reg_gender_unk                     		Count of voters registered on or before: 2021-03-30, L2 Gender: Unknown
s20210330_pct_voted_gender_unk               		Percent of voters registered on or before 2021-03-30 and who voted in: special_2021_03_30, L2 Gender: Unknown
s20210330_voted_eur                          		Count of voters who voted in the following election: special_2021_03_30, L2 Race or Ethnicity: European
s20210330_reg_eur                            		Count of voters registered on or before: 2021-03-30, L2 Race or Ethnicity: European
s20210330_pct_voted_eur                      		Percent of voters registered on or before 2021-03-30 and who voted in: special_2021_03_30, L2 Race or Ethnicity: European
s20210330_voted_hisp                         		Count of voters who voted in the following election: special_2021_03_30, L2 Race or Ethnicity: Hispanic and Portuguese
s20210330_reg_hisp                           		Count of voters registered on or before: 2021-03-30, L2 Race or Ethnicity: Hispanic and Portuguese
s20210330_pct_voted_hisp                     		Percent of voters registered on or before 2021-03-30 and who voted in: special_2021_03_30, L2 Race or Ethnicity: Hispanic and Portuguese
s20210330_voted_aa                           		Count of voters who voted in the following election: special_2021_03_30, L2 Race or Ethnicity: Likely African-American
s20210330_reg_aa                             		Count of voters registered on or before: 2021-03-30, L2 Race or Ethnicity: Likely African-American
s20210330_pct_voted_aa                       		Percent of voters registered on or before 2021-03-30 and who voted in: special_2021_03_30, L2 Race or Ethnicity: Likely African-American
s20210330_voted_esa                          		Count of voters who voted in the following election: special_2021_03_30, L2 Race or Ethnicity: East and South Asian
s20210330_reg_esa                            		Count of voters registered on or before: 2021-03-30, L2 Race or Ethnicity: East and South Asian
s20210330_pct_voted_esa                      		Percent of voters registered on or before 2021-03-30 and who voted in: special_2021_03_30, L2 Race or Ethnicity: East and South Asian
s20210330_voted_oth                          		Count of voters who voted in the following election: special_2021_03_30, L2 Race or Ethnicity: Other
s20210330_reg_oth                            		Count of voters registered on or before: 2021-03-30, L2 Race or Ethnicity: Other
s20210330_pct_voted_oth                      		Percent of voters registered on or before 2021-03-30 and who voted in: special_2021_03_30, L2 Race or Ethnicity: Other
s20210330_voted_unk                          		Count of voters who voted in the following election: special_2021_03_30, L2 Race or Ethnicity: Unknown
s20210330_reg_unk                            		Count of voters registered on or before: 2021-03-30, L2 Race or Ethnicity: Unknown
s20210330_pct_voted_unk                      		Percent of voters registered on or before 2021-03-30 and who voted in: special_2021_03_30, L2 Race or Ethnicity: Unknown
s20210302_voted_all                          		Count of voters who voted in the following election: special_2021_03_02
s20210302_reg_all                            		Count of voters registered on or before: 2021-03-02
s20210302_pct_voted_all                      		Percent of voters registered on or before 2021-03-02 and who voted in: special_2021_03_02
s20210302_voted_gender_m                     		Count of voters who voted in the following election: special_2021_03_02, L2 Gender: Male
s20210302_reg_gender_m                       		Count of voters registered on or before: 2021-03-02, L2 Gender: Male
s20210302_pct_voted_gender_m                 		Percent of voters registered on or before 2021-03-02 and who voted in: special_2021_03_02, L2 Gender: Male
s20210302_voted_gender_f                     		Count of voters who voted in the following election: special_2021_03_02, L2 Gender: Female
s20210302_reg_gender_f                       		Count of voters registered on or before: 2021-03-02, L2 Gender: Female
s20210302_pct_voted_gender_f                 		Percent of voters registered on or before 2021-03-02 and who voted in: special_2021_03_02, L2 Gender: Female
s20210302_voted_gender_unk                   		Count of voters who voted in the following election: special_2021_03_02, L2 Gender: Unknown
s20210302_reg_gender_unk                     		Count of voters registered on or before: 2021-03-02, L2 Gender: Unknown
s20210302_pct_voted_gender_unk               		Percent of voters registered on or before 2021-03-02 and who voted in: special_2021_03_02, L2 Gender: Unknown
s20210302_voted_eur                          		Count of voters who voted in the following election: special_2021_03_02, L2 Race or Ethnicity: European
s20210302_reg_eur                            		Count of voters registered on or before: 2021-03-02, L2 Race or Ethnicity: European
s20210302_pct_voted_eur                      		Percent of voters registered on or before 2021-03-02 and who voted in: special_2021_03_02, L2 Race or Ethnicity: European
s20210302_voted_hisp                         		Count of voters who voted in the following election: special_2021_03_02, L2 Race or Ethnicity: Hispanic and Portuguese
s20210302_reg_hisp                           		Count of voters registered on or before: 2021-03-02, L2 Race or Ethnicity: Hispanic and Portuguese
s20210302_pct_voted_hisp                     		Percent of voters registered on or before 2021-03-02 and who voted in: special_2021_03_02, L2 Race or Ethnicity: Hispanic and Portuguese
s20210302_voted_aa                           		Count of voters who voted in the following election: special_2021_03_02, L2 Race or Ethnicity: Likely African-American
s20210302_reg_aa                             		Count of voters registered on or before: 2021-03-02, L2 Race or Ethnicity: Likely African-American
s20210302_pct_voted_aa                       		Percent of voters registered on or before 2021-03-02 and who voted in: special_2021_03_02, L2 Race or Ethnicity: Likely African-American
s20210302_voted_esa                          		Count of voters who voted in the following election: special_2021_03_02, L2 Race or Ethnicity: East and South Asian
s20210302_reg_esa                            		Count of voters registered on or before: 2021-03-02, L2 Race or Ethnicity: East and South Asian
s20210302_pct_voted_esa                      		Percent of voters registered on or before 2021-03-02 and who voted in: special_2021_03_02, L2 Race or Ethnicity: East and South Asian
s20210302_voted_oth                          		Count of voters who voted in the following election: special_2021_03_02, L2 Race or Ethnicity: Other
s20210302_reg_oth                            		Count of voters registered on or before: 2021-03-02, L2 Race or Ethnicity: Other
s20210302_pct_voted_oth                      		Percent of voters registered on or before 2021-03-02 and who voted in: special_2021_03_02, L2 Race or Ethnicity: Other
s20210302_voted_unk                          		Count of voters who voted in the following election: special_2021_03_02, L2 Race or Ethnicity: Unknown
s20210302_reg_unk                            		Count of voters registered on or before: 2021-03-02, L2 Race or Ethnicity: Unknown
s20210302_pct_voted_unk                      		Percent of voters registered on or before 2021-03-02 and who voted in: special_2021_03_02, L2 Race or Ethnicity: Unknown
g20201103_voted_all                          		Count of voters who voted in the following election: general_2020_11_03
g20201103_reg_all                            		Count of voters registered on or before: 2020-11-03
g20201103_pct_voted_all                      		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03
g20201103_voted_gender_m                     		Count of voters who voted in the following election: general_2020_11_03, L2 Gender: Male
g20201103_reg_gender_m                       		Count of voters registered on or before: 2020-11-03, L2 Gender: Male
g20201103_pct_voted_gender_m                 		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Gender: Male
g20201103_voted_gender_f                     		Count of voters who voted in the following election: general_2020_11_03, L2 Gender: Female
g20201103_reg_gender_f                       		Count of voters registered on or before: 2020-11-03, L2 Gender: Female
g20201103_pct_voted_gender_f                 		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Gender: Female
g20201103_voted_gender_unk                   		Count of voters who voted in the following election: general_2020_11_03, L2 Gender: Unknown
g20201103_reg_gender_unk                     		Count of voters registered on or before: 2020-11-03, L2 Gender: Unknown
g20201103_pct_voted_gender_unk               		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Gender: Unknown
g20201103_voted_eur                          		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: European
g20201103_reg_eur                            		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: European
g20201103_pct_voted_eur                      		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: European
g20201103_voted_hisp                         		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: Hispanic and Portuguese
g20201103_reg_hisp                           		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: Hispanic and Portuguese
g20201103_pct_voted_hisp                     		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: Hispanic and Portuguese
g20201103_voted_aa                           		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: Likely African-American
g20201103_reg_aa                             		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: Likely African-American
g20201103_pct_voted_aa                       		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: Likely African-American
g20201103_voted_esa                          		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: East and South Asian
g20201103_reg_esa                            		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: East and South Asian
g20201103_pct_voted_esa                      		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: East and South Asian
g20201103_voted_oth                          		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: Other
g20201103_reg_oth                            		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: Other
g20201103_pct_voted_oth                      		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: Other
g20201103_voted_unk                          		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: Unknown
g20201103_reg_unk                            		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: Unknown
g20201103_pct_voted_unk                      		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: Unknown
p20200901_voted_all                          		Count of voters who voted in the following election: primary_2020_09_01
p20200901_reg_all                            		Count of voters registered on or before: 2020-09-01
p20200901_pct_voted_all                      		Percent of voters registered on or before 2020-09-01 and who voted in: primary_2020_09_01
p20200901_voted_gender_m                     		Count of voters who voted in the following election: primary_2020_09_01, L2 Gender: Male
p20200901_reg_gender_m                       		Count of voters registered on or before: 2020-09-01, L2 Gender: Male
p20200901_pct_voted_gender_m                 		Percent of voters registered on or before 2020-09-01 and who voted in: primary_2020_09_01, L2 Gender: Male
p20200901_voted_gender_f                     		Count of voters who voted in the following election: primary_2020_09_01, L2 Gender: Female
p20200901_reg_gender_f                       		Count of voters registered on or before: 2020-09-01, L2 Gender: Female
p20200901_pct_voted_gender_f                 		Percent of voters registered on or before 2020-09-01 and who voted in: primary_2020_09_01, L2 Gender: Female
p20200901_voted_gender_unk                   		Count of voters who voted in the following election: primary_2020_09_01, L2 Gender: Unknown
p20200901_reg_gender_unk                     		Count of voters registered on or before: 2020-09-01, L2 Gender: Unknown
p20200901_pct_voted_gender_unk               		Percent of voters registered on or before 2020-09-01 and who voted in: primary_2020_09_01, L2 Gender: Unknown
p20200901_voted_eur                          		Count of voters who voted in the following election: primary_2020_09_01, L2 Race or Ethnicity: European
p20200901_reg_eur                            		Count of voters registered on or before: 2020-09-01, L2 Race or Ethnicity: European
p20200901_pct_voted_eur                      		Percent of voters registered on or before 2020-09-01 and who voted in: primary_2020_09_01, L2 Race or Ethnicity: European
p20200901_voted_hisp                         		Count of voters who voted in the following election: primary_2020_09_01, L2 Race or Ethnicity: Hispanic and Portuguese
p20200901_reg_hisp                           		Count of voters registered on or before: 2020-09-01, L2 Race or Ethnicity: Hispanic and Portuguese
p20200901_pct_voted_hisp                     		Percent of voters registered on or before 2020-09-01 and who voted in: primary_2020_09_01, L2 Race or Ethnicity: Hispanic and Portuguese
p20200901_voted_aa                           		Count of voters who voted in the following election: primary_2020_09_01, L2 Race or Ethnicity: Likely African-American
p20200901_reg_aa                             		Count of voters registered on or before: 2020-09-01, L2 Race or Ethnicity: Likely African-American
p20200901_pct_voted_aa                       		Percent of voters registered on or before 2020-09-01 and who voted in: primary_2020_09_01, L2 Race or Ethnicity: Likely African-American
p20200901_voted_esa                          		Count of voters who voted in the following election: primary_2020_09_01, L2 Race or Ethnicity: East and South Asian
p20200901_reg_esa                            		Count of voters registered on or before: 2020-09-01, L2 Race or Ethnicity: East and South Asian
p20200901_pct_voted_esa                      		Percent of voters registered on or before 2020-09-01 and who voted in: primary_2020_09_01, L2 Race or Ethnicity: East and South Asian
p20200901_voted_oth                          		Count of voters who voted in the following election: primary_2020_09_01, L2 Race or Ethnicity: Other
p20200901_reg_oth                            		Count of voters registered on or before: 2020-09-01, L2 Race or Ethnicity: Other
p20200901_pct_voted_oth                      		Percent of voters registered on or before 2020-09-01 and who voted in: primary_2020_09_01, L2 Race or Ethnicity: Other
p20200901_voted_unk                          		Count of voters who voted in the following election: primary_2020_09_01, L2 Race or Ethnicity: Unknown
p20200901_reg_unk                            		Count of voters registered on or before: 2020-09-01, L2 Race or Ethnicity: Unknown
p20200901_pct_voted_unk                      		Percent of voters registered on or before 2020-09-01 and who voted in: primary_2020_09_01, L2 Race or Ethnicity: Unknown
s20200602_voted_all                          		Count of voters who voted in the following election: special_2020_06_02
s20200602_reg_all                            		Count of voters registered on or before: 2020-06-02
s20200602_pct_voted_all                      		Percent of voters registered on or before 2020-06-02 and who voted in: special_2020_06_02
s20200602_voted_gender_m                     		Count of voters who voted in the following election: special_2020_06_02, L2 Gender: Male
s20200602_reg_gender_m                       		Count of voters registered on or before: 2020-06-02, L2 Gender: Male
s20200602_pct_voted_gender_m                 		Percent of voters registered on or before 2020-06-02 and who voted in: special_2020_06_02, L2 Gender: Male
s20200602_voted_gender_f                     		Count of voters who voted in the following election: special_2020_06_02, L2 Gender: Female
s20200602_reg_gender_f                       		Count of voters registered on or before: 2020-06-02, L2 Gender: Female
s20200602_pct_voted_gender_f                 		Percent of voters registered on or before 2020-06-02 and who voted in: special_2020_06_02, L2 Gender: Female
s20200602_voted_gender_unk                   		Count of voters who voted in the following election: special_2020_06_02, L2 Gender: Unknown
s20200602_reg_gender_unk                     		Count of voters registered on or before: 2020-06-02, L2 Gender: Unknown
s20200602_pct_voted_gender_unk               		Percent of voters registered on or before 2020-06-02 and who voted in: special_2020_06_02, L2 Gender: Unknown
s20200602_voted_eur                          		Count of voters who voted in the following election: special_2020_06_02, L2 Race or Ethnicity: European
s20200602_reg_eur                            		Count of voters registered on or before: 2020-06-02, L2 Race or Ethnicity: European
s20200602_pct_voted_eur                      		Percent of voters registered on or before 2020-06-02 and who voted in: special_2020_06_02, L2 Race or Ethnicity: European
s20200602_voted_hisp                         		Count of voters who voted in the following election: special_2020_06_02, L2 Race or Ethnicity: Hispanic and Portuguese
s20200602_reg_hisp                           		Count of voters registered on or before: 2020-06-02, L2 Race or Ethnicity: Hispanic and Portuguese
s20200602_pct_voted_hisp                     		Percent of voters registered on or before 2020-06-02 and who voted in: special_2020_06_02, L2 Race or Ethnicity: Hispanic and Portuguese
s20200602_voted_aa                           		Count of voters who voted in the following election: special_2020_06_02, L2 Race or Ethnicity: Likely African-American
s20200602_reg_aa                             		Count of voters registered on or before: 2020-06-02, L2 Race or Ethnicity: Likely African-American
s20200602_pct_voted_aa                       		Percent of voters registered on or before 2020-06-02 and who voted in: special_2020_06_02, L2 Race or Ethnicity: Likely African-American
s20200602_voted_esa                          		Count of voters who voted in the following election: special_2020_06_02, L2 Race or Ethnicity: East and South Asian
s20200602_reg_esa                            		Count of voters registered on or before: 2020-06-02, L2 Race or Ethnicity: East and South Asian
s20200602_pct_voted_esa                      		Percent of voters registered on or before 2020-06-02 and who voted in: special_2020_06_02, L2 Race or Ethnicity: East and South Asian
s20200602_voted_oth                          		Count of voters who voted in the following election: special_2020_06_02, L2 Race or Ethnicity: Other
s20200602_reg_oth                            		Count of voters registered on or before: 2020-06-02, L2 Race or Ethnicity: Other
s20200602_pct_voted_oth                      		Percent of voters registered on or before 2020-06-02 and who voted in: special_2020_06_02, L2 Race or Ethnicity: Other
s20200602_voted_unk                          		Count of voters who voted in the following election: special_2020_06_02, L2 Race or Ethnicity: Unknown
s20200602_reg_unk                            		Count of voters registered on or before: 2020-06-02, L2 Race or Ethnicity: Unknown
s20200602_pct_voted_unk                      		Percent of voters registered on or before 2020-06-02 and who voted in: special_2020_06_02, L2 Race or Ethnicity: Unknown
pp20200303_voted_all                         		Count of voters who voted in the following election: presidential_primary_2020_03_03
pp20200303_reg_all                           		Count of voters registered on or before: 2020-03-03
pp20200303_pct_voted_all                     		Percent of voters registered on or before 2020-03-03 and who voted in: presidential_primary_2020_03_03
pp20200303_voted_gender_m                    		Count of voters who voted in the following election: presidential_primary_2020_03_03, L2 Gender: Male
pp20200303_reg_gender_m                      		Count of voters registered on or before: 2020-03-03, L2 Gender: Male
pp20200303_pct_voted_gender_m                		Percent of voters registered on or before 2020-03-03 and who voted in: presidential_primary_2020_03_03, L2 Gender: Male
pp20200303_voted_gender_f                    		Count of voters who voted in the following election: presidential_primary_2020_03_03, L2 Gender: Female
pp20200303_reg_gender_f                      		Count of voters registered on or before: 2020-03-03, L2 Gender: Female
pp20200303_pct_voted_gender_f                		Percent of voters registered on or before 2020-03-03 and who voted in: presidential_primary_2020_03_03, L2 Gender: Female
pp20200303_voted_gender_unk                  		Count of voters who voted in the following election: presidential_primary_2020_03_03, L2 Gender: Unknown
pp20200303_reg_gender_unk                    		Count of voters registered on or before: 2020-03-03, L2 Gender: Unknown
pp20200303_pct_voted_gender_unk              		Percent of voters registered on or before 2020-03-03 and who voted in: presidential_primary_2020_03_03, L2 Gender: Unknown
pp20200303_voted_eur                         		Count of voters who voted in the following election: presidential_primary_2020_03_03, L2 Race or Ethnicity: European
pp20200303_reg_eur                           		Count of voters registered on or before: 2020-03-03, L2 Race or Ethnicity: European
pp20200303_pct_voted_eur                     		Percent of voters registered on or before 2020-03-03 and who voted in: presidential_primary_2020_03_03, L2 Race or Ethnicity: European
pp20200303_voted_hisp                        		Count of voters who voted in the following election: presidential_primary_2020_03_03, L2 Race or Ethnicity: Hispanic and Portuguese
pp20200303_reg_hisp                          		Count of voters registered on or before: 2020-03-03, L2 Race or Ethnicity: Hispanic and Portuguese
pp20200303_pct_voted_hisp                    		Percent of voters registered on or before 2020-03-03 and who voted in: presidential_primary_2020_03_03, L2 Race or Ethnicity: Hispanic and Portuguese
pp20200303_voted_aa                          		Count of voters who voted in the following election: presidential_primary_2020_03_03, L2 Race or Ethnicity: Likely African-American
pp20200303_reg_aa                            		Count of voters registered on or before: 2020-03-03, L2 Race or Ethnicity: Likely African-American
pp20200303_pct_voted_aa                      		Percent of voters registered on or before 2020-03-03 and who voted in: presidential_primary_2020_03_03, L2 Race or Ethnicity: Likely African-American
pp20200303_voted_esa                         		Count of voters who voted in the following election: presidential_primary_2020_03_03, L2 Race or Ethnicity: East and South Asian
pp20200303_reg_esa                           		Count of voters registered on or before: 2020-03-03, L2 Race or Ethnicity: East and South Asian
pp20200303_pct_voted_esa                     		Percent of voters registered on or before 2020-03-03 and who voted in: presidential_primary_2020_03_03, L2 Race or Ethnicity: East and South Asian
pp20200303_voted_oth                         		Count of voters who voted in the following election: presidential_primary_2020_03_03, L2 Race or Ethnicity: Other
pp20200303_reg_oth                           		Count of voters registered on or before: 2020-03-03, L2 Race or Ethnicity: Other
pp20200303_pct_voted_oth                     		Percent of voters registered on or before 2020-03-03 and who voted in: presidential_primary_2020_03_03, L2 Race or Ethnicity: Other
pp20200303_voted_unk                         		Count of voters who voted in the following election: presidential_primary_2020_03_03, L2 Race or Ethnicity: Unknown
pp20200303_reg_unk                           		Count of voters registered on or before: 2020-03-03, L2 Race or Ethnicity: Unknown
pp20200303_pct_voted_unk                     		Percent of voters registered on or before 2020-03-03 and who voted in: presidential_primary_2020_03_03, L2 Race or Ethnicity: Unknown

## Processing 
L2 provides individual address data for every voter on their voter file. 
Many of the voters contain latitude/longitude data. The RDH assigns 2020 Census blocks to voters containing latitude/longitude data by spatially joining the points with Census block files. 
Voters that are assigned to a block in a county that does not match their county on the voter file are removed as a quality control check. 
The individual data is aggregated to the block-level by grouping by block assignments. Individuals who could not be assigned a Census block because of missing latitude/longitude were assigned “NO ASSIGNMENT - [county fips code assignment]" and therefore reported as county aggregates in the geoid20 column.

## Additional Notes 
The fields in this file correspond to those voters registered to vote at their residence as of the date mentioned above. 
The vote history fields are tied to individual voters, then aggregated up - not tied to blocks as a whole, and as such represent whether or not voters in the block as of the L2 voter file date above voted *anywhere*, not necessarily specifically in that block. 
As such, this information can be used to approximate how the demographic in the block voted historically, but cannot be used to track how individuals in that block voted at the time of previous elections. For snapshots from previous voter files, please reference previous voter files hosted by the RDH. 

The RDH cannot certify the accuracy of any of the information contained within this file.

* RDH is providing aggregates of the top 8 parties in the state. 
** For the narrow ethnicity categories, RDH is providing an aggregate of all ethnicities that have more than 
1000 individuals state-wide. L2 ethnicity categories use modeling techniques to infer an individual's ethnicity.
Please see the attached PDF for  more information about L2's ethnicity fields. 


Please contact info@redistrictingdatahub.org for more information. 